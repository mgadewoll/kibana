"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.isCustomItemAction = exports.callWithItemIfFunction = void 0;
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

var isCustomItemAction = exports.isCustomItemAction = function isCustomItemAction(action) {
  return action.hasOwnProperty('render');
};
var callWithItemIfFunction = exports.callWithItemIfFunction = function callWithItemIfFunction(item) {
  return function (prop) {
    return typeof prop === 'function' ? prop(item) : prop;
  };
};