"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.euiDataGridPaginationStyles = void 0;
var _react = require("@emotion/react");
var _global_styling = require("../../../global_styling");
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

var euiDataGridPaginationStyles = exports.euiDataGridPaginationStyles = function euiDataGridPaginationStyles(_ref) {
  var euiTheme = _ref.euiTheme;
  return {
    euiDataGrid__pagination: /*#__PURE__*/(0, _react.css)("z-index:2;flex-grow:0;", (0, _global_styling.logicalCSS)('padding-top', euiTheme.size.xs), " .euiDataGrid--fullScreen &{position:relative;", (0, _global_styling.logicalCSS)('padding-bottom', euiTheme.size.xs), " background-color:", euiTheme.colors.lightestShade, ";&::before{content:'';position:absolute;", (0, _global_styling.logicalCSS)('top', "-".concat(euiTheme.border.width.thin)), " ", (0, _global_styling.logicalCSS)('horizontal', 0), " ", (0, _global_styling.logicalCSS)('border-top', euiTheme.border.thin), " pointer-events:none;}};label:euiDataGrid__pagination;")
  };
};