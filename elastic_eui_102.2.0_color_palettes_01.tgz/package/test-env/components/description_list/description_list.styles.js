"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.euiDescriptionListStyles = void 0;
var _react = require("@emotion/react");
var _global_styling = require("../../global_styling");
function _EMOTION_STRINGIFIED_CSS_ERROR__() { return "You have tried to stringify object returned from `css` function. It isn't supposed to be used directly (e.g. as value of the `className` prop), but rather handed to emotion so it can handle it (e.g. as value of `css` prop)."; } /*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
var _ref = process.env.NODE_ENV === "production" ? {
  name: "zr5fhc-column",
  styles: "display:grid;grid-template-columns:minmax(auto, max-content) minmax(auto, max-content);align-items:baseline;label:column;"
} : {
  name: "zr5fhc-column",
  styles: "display:grid;grid-template-columns:minmax(auto, max-content) minmax(auto, max-content);align-items:baseline;label:column;",
  toString: _EMOTION_STRINGIFIED_CSS_ERROR__
};
var euiDescriptionListStyles = exports.euiDescriptionListStyles = function euiDescriptionListStyles(euiThemeContext) {
  return {
    euiDescriptionList: /*#__PURE__*/(0, _react.css)(";label:euiDescriptionList;"),
    // Types
    row: /*#__PURE__*/(0, _react.css)(";label:row;"),
    inline: /*#__PURE__*/(0, _react.css)(";label:inline;"),
    column: _ref,
    columnGap: {
      s: /*#__PURE__*/(0, _react.css)("column-gap:", euiThemeContext.euiTheme.size.s, ";;label:s;"),
      m: /*#__PURE__*/(0, _react.css)("column-gap:", euiThemeContext.euiTheme.size.xl, ";;label:m;")
    },
    rowGap: {
      s: /*#__PURE__*/(0, _react.css)("row-gap:", euiThemeContext.euiTheme.size.s, ";;label:s;"),
      m: /*#__PURE__*/(0, _react.css)("row-gap:", euiThemeContext.euiTheme.size.m, ";;label:m;")
    },
    // Alignment
    center: /*#__PURE__*/(0, _react.css)((0, _global_styling.logicalTextAlignCSS)('center'), ";;label:center;"),
    left: /*#__PURE__*/(0, _react.css)((0, _global_styling.logicalTextAlignCSS)('left'), ";;label:left;")
  };
};