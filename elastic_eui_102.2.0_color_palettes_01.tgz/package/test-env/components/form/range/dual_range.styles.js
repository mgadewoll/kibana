"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.euiDualRangeStyles = void 0;
var _react = require("@emotion/react");
var _range = require("./range.styles");
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

var euiDualRangeStyles = exports.euiDualRangeStyles = function euiDualRangeStyles() {
  return {
    euiDualRange: /*#__PURE__*/(0, _react.css)(";label:euiDualRange;"),
    euiDualRange__slider: /*#__PURE__*/(0, _react.css)((0, _range.euiRangeThumbPerBrowser)('visibility: hidden'), ";;label:euiDualRange__slider;")
  };
};