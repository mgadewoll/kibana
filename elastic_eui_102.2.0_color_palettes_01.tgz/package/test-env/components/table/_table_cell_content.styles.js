"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.euiTableCellContentStyles = void 0;
var _react = require("@emotion/react");
var _global_styling = require("../../global_styling");
function _EMOTION_STRINGIFIED_CSS_ERROR__() { return "You have tried to stringify object returned from `css` function. It isn't supposed to be used directly (e.g. as value of the `className` prop), but rather handed to emotion so it can handle it (e.g. as value of `css` prop)."; } /*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
var _ref = process.env.NODE_ENV === "production" ? {
  name: "1t1ptlc-mobile",
  styles: "flex-direction:column;padding:0;label:mobile;"
} : {
  name: "1t1ptlc-mobile",
  styles: "flex-direction:column;padding:0;label:mobile;",
  toString: _EMOTION_STRINGIFIED_CSS_ERROR__
};
var _ref2 = process.env.NODE_ENV === "production" ? {
  name: "o9tdjd-desktop",
  styles: "flex-wrap:wrap;label:desktop;"
} : {
  name: "o9tdjd-desktop",
  styles: "flex-wrap:wrap;label:desktop;",
  toString: _EMOTION_STRINGIFIED_CSS_ERROR__
};
var _ref3 = process.env.NODE_ENV === "production" ? {
  name: "1x3x3jh-center",
  styles: "justify-content:center;text-align:center;label:center;"
} : {
  name: "1x3x3jh-center",
  styles: "justify-content:center;text-align:center;label:center;",
  toString: _EMOTION_STRINGIFIED_CSS_ERROR__
};
var _ref4 = process.env.NODE_ENV === "production" ? {
  name: "1vsid2d-euiTableCellContent",
  styles: "display:flex;align-items:center;label:euiTableCellContent;"
} : {
  name: "1vsid2d-euiTableCellContent",
  styles: "display:flex;align-items:center;label:euiTableCellContent;",
  toString: _EMOTION_STRINGIFIED_CSS_ERROR__
};
var euiTableCellContentStyles = exports.euiTableCellContentStyles = function euiTableCellContentStyles(_ref5) {
  var euiTheme = _ref5.euiTheme;
  return {
    euiTableCellContent: _ref4,
    // Align
    left: null,
    // Default, no CSS needed
    right: /*#__PURE__*/(0, _react.css)("justify-content:flex-end;", (0, _global_styling.logicalTextAlignCSS)('right'), ";;label:right;"),
    center: _ref3,
    // Text wrapping
    truncateText: /*#__PURE__*/(0, _react.css)((0, _global_styling.euiTextTruncate)(), ".euiTableCellContent__text{overflow:hidden;text-overflow:ellipsis;};label:truncateText;"),
    wrapText: /*#__PURE__*/(0, _react.css)((0, _global_styling.euiTextBreakWord)(), ";;label:wrapText;"),
    // Action cells
    hasActions: {
      actions: /*#__PURE__*/(0, _react.css)("gap:", euiTheme.size.s, ";;label:actions;"),
      desktop: _ref2,
      mobile: _ref
    }
  };
};