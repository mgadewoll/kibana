"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
var _typeof = require("@babel/runtime/helpers/typeof");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.EuiTourHeader = void 0;
var _react = _interopRequireWildcard(require("react"));
var _propTypes = _interopRequireDefault(require("prop-types"));
var _services = require("../../services");
var _popover = require("../popover");
var _title = require("../title");
var _tour_header = require("./_tour_header.styles");
var _react2 = require("@emotion/react");
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != _typeof(e) && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

var EuiTourHeader = exports.EuiTourHeader = /*#__PURE__*/(0, _react.memo)(function (_ref) {
  var id = _ref.id,
    title = _ref.title,
    subtitle = _ref.subtitle;
  var headerStyles = (0, _services.useEuiMemoizedStyles)(_tour_header.euiTourHeaderStyles);
  return (0, _react2.jsx)(_popover.EuiPopoverTitle, {
    css: headerStyles.euiTourHeader,
    className: "euiTourHeader",
    id: id
  }, subtitle && (0, _react2.jsx)(_title.EuiTitle, {
    css: headerStyles.euiTourHeader__subtitle,
    size: "xxxs"
  }, (0, _react2.jsx)("h2", null, subtitle)), (0, _react2.jsx)(_title.EuiTitle, {
    css: headerStyles.euiTourHeader__title,
    size: "xxs"
  }, subtitle ? (0, _react2.jsx)("h3", null, title) : (0, _react2.jsx)("h2", null, title)));
});
EuiTourHeader.propTypes = {
  id: _propTypes.default.string.isRequired
};
EuiTourHeader.displayName = '_EuiTourHeader';