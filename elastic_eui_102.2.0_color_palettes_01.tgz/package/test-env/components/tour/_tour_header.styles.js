"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.euiTourHeaderStyles = void 0;
var _react = require("@emotion/react");
var _global_styling = require("../../global_styling");
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

var euiTourHeaderStyles = exports.euiTourHeaderStyles = function euiTourHeaderStyles(_ref) {
  var euiTheme = _ref.euiTheme;
  return {
    // Base
    euiTourHeader: /*#__PURE__*/(0, _react.css)((0, _global_styling.logicalCSS)('border-bottom', 'none'), (0, _global_styling.logicalCSS)('margin-bottom', euiTheme.size.s), ";;label:euiTourHeader;"),
    // Elements
    euiTourHeader__title: /*#__PURE__*/(0, _react.css)((0, _global_styling.logicalCSS)('margin-top', 0), ";;label:euiTourHeader__title;"),
    euiTourHeader__subtitle: /*#__PURE__*/(0, _react.css)("color:", euiTheme.colors.textSubdued, ";padding-block-end:", euiTheme.size.xs, ";;label:euiTourHeader__subtitle;")
  };
};