"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.RIGHT_ALIGNMENT = exports.LEFT_ALIGNMENT = exports.CENTER_ALIGNMENT = void 0;
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

var LEFT_ALIGNMENT = exports.LEFT_ALIGNMENT = 'left';
var RIGHT_ALIGNMENT = exports.RIGHT_ALIGNMENT = 'right';
var CENTER_ALIGNMENT = exports.CENTER_ALIGNMENT = 'center';