"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.CanvasTextUtils = void 0;
var _createClass2 = _interopRequireDefault(require("@babel/runtime/helpers/createClass"));
var _classCallCheck2 = _interopRequireDefault(require("@babel/runtime/helpers/classCallCheck"));
var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
var CanvasTextUtils = exports.CanvasTextUtils = /*#__PURE__*/(0, _createClass2.default)(function CanvasTextUtils(_) {
  var _this = this;
  (0, _classCallCheck2.default)(this, CanvasTextUtils);
  (0, _defineProperty2.default)(this, "computeFontFromElement", function (_) {
    return '';
  });
  (0, _defineProperty2.default)(this, "textWidth", 0);
  (0, _defineProperty2.default)(this, "currentText", '');
  (0, _defineProperty2.default)(this, "setTextToCheck", function (text) {
    _this.currentText = text;
  });
});