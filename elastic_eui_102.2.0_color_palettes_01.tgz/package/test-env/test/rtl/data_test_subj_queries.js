"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.queryByTestSubject = exports.queryAllByTestSubject = exports.getByTestSubject = exports.getAllByTestSubject = exports.findByTestSubject = exports.findAllByTestSubject = void 0;
var _slicedToArray2 = _interopRequireDefault(require("@babel/runtime/helpers/slicedToArray"));
var _react = require("@testing-library/react");
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

var queryAllByTestSubject = exports.queryAllByTestSubject = function queryAllByTestSubject() {
  for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
    args[_key] = arguments[_key];
  }
  return _react.queryHelpers.queryAllByAttribute.apply(_react.queryHelpers, ['data-test-subj'].concat(args));
};
var getMultipleError = function getMultipleError(_, TestSubjectValue) {
  return "Found multiple elements with the data-test-subj attribute of: ".concat(TestSubjectValue);
};
var getMissingError = function getMissingError(_, TestSubjectValue) {
  return "Unable to find an element with the data-test-subj attribute of: ".concat(TestSubjectValue);
};
var _buildQueries = (0, _react.buildQueries)(queryAllByTestSubject, getMultipleError, getMissingError),
  _buildQueries2 = (0, _slicedToArray2.default)(_buildQueries, 5),
  queryByTestSubject = exports.queryByTestSubject = _buildQueries2[0],
  getAllByTestSubject = exports.getAllByTestSubject = _buildQueries2[1],
  getByTestSubject = exports.getByTestSubject = _buildQueries2[2],
  findAllByTestSubject = exports.findAllByTestSubject = _buildQueries2[3],
  findByTestSubject = exports.findByTestSubject = _buildQueries2[4];