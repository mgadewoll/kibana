"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "breakpoint", {
  enumerable: true,
  get: function get() {
    return _euiThemeCommon.breakpoint;
  }
});
var _euiThemeCommon = require("@elastic/eui-theme-common");