"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.buttons = void 0;
var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));
var _slicedToArray2 = _interopRequireDefault(require("@babel/runtime/helpers/slicedToArray"));
var _toConsumableArray2 = _interopRequireDefault(require("@babel/runtime/helpers/toConsumableArray"));
var _euiThemeCommon = require("@elastic/eui-theme-common");
var _hex_to_rgb = require("../../../../services/color/hex_to_rgb");
var _is_color_dark = require("../../../../services/color/is_color_dark");
var _manipulation = require("../../../../services/color/manipulation");
var _colors_severity = require("./_colors_severity");
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { (0, _defineProperty2.default)(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; } /*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
var isDark = function isDark(background) {
  return background ? _is_color_dark.isColorDark.apply(void 0, (0, _toConsumableArray2.default)((0, _hex_to_rgb.hexToRgb)(background))) : false;
};
var _buttons = {
  backgroundPrimary: (0, _euiThemeCommon.computed)(function (_ref) {
    var _ref2 = (0, _slicedToArray2.default)(_ref, 1),
      backgroundLightPrimary = _ref2[0];
    return backgroundLightPrimary;
  }, ['colors.backgroundLightPrimary']),
  backgroundAccent: (0, _euiThemeCommon.computed)(function (_ref3) {
    var _ref4 = (0, _slicedToArray2.default)(_ref3, 1),
      backgroundLightAccent = _ref4[0];
    return backgroundLightAccent;
  }, ['colors.backgroundLightAccent']),
  backgroundAccentSecondary: (0, _euiThemeCommon.computed)(function (_ref5) {
    var _ref6 = (0, _slicedToArray2.default)(_ref5, 1),
      backgroundLightAccentSecondary = _ref6[0];
    return backgroundLightAccentSecondary;
  }, ['colors.backgroundLightAccentSecondary']),
  backgroundNeutral: (0, _euiThemeCommon.computed)(function (_ref7) {
    var _ref8 = (0, _slicedToArray2.default)(_ref7, 1),
      backgroundLightNeutral = _ref8[0];
    return backgroundLightNeutral;
  }, ['colors.backgroundLightNeutral']),
  backgroundSuccess: (0, _euiThemeCommon.computed)(function (_ref9) {
    var _ref10 = (0, _slicedToArray2.default)(_ref9, 1),
      backgroundLightSuccess = _ref10[0];
    return backgroundLightSuccess;
  }, ['colors.backgroundLightSuccess']),
  backgroundWarning: (0, _euiThemeCommon.computed)(function (_ref11) {
    var _ref12 = (0, _slicedToArray2.default)(_ref11, 1),
      backgroundLightWarning = _ref12[0];
    return backgroundLightWarning;
  }, ['colors.backgroundLightWarning']),
  backgroundRisk: (0, _euiThemeCommon.computed)(function (_ref13) {
    var _ref14 = (0, _slicedToArray2.default)(_ref13, 1),
      backgroundLightRisk = _ref14[0];
    return backgroundLightRisk;
  }, ['colors.backgroundLightRisk']),
  backgroundDanger: (0, _euiThemeCommon.computed)(function (_ref15) {
    var _ref16 = (0, _slicedToArray2.default)(_ref15, 1),
      backgroundLightDanger = _ref16[0];
    return backgroundLightDanger;
  }, ['colors.backgroundLightDanger']),
  backgroundText: (0, _euiThemeCommon.computed)(function (_ref17) {
    var _ref18 = (0, _slicedToArray2.default)(_ref17, 1),
      backgroundLightText = _ref18[0];
    return backgroundLightText;
  }, ['colors.backgroundLightText']),
  backgroundDisabled: (0, _euiThemeCommon.computed)(function (_ref19) {
    var _ref20 = (0, _slicedToArray2.default)(_ref19, 1),
      lightShade = _ref20[0];
    return (0, _manipulation.transparentize)(lightShade, 0.15);
  }, ['colors.lightShade']),
  backgroundFilledPrimary: (0, _euiThemeCommon.computed)(function (_ref21) {
    var _ref22 = (0, _slicedToArray2.default)(_ref21, 1),
      backgroundFilledPrimary = _ref22[0];
    return backgroundFilledPrimary;
  }, ['colors.backgroundFilledPrimary']),
  backgroundFilledAccent: (0, _euiThemeCommon.computed)(function (_ref23) {
    var _ref24 = (0, _slicedToArray2.default)(_ref23, 1),
      backgroundFilledAccent = _ref24[0];
    return backgroundFilledAccent;
  }, ['colors.backgroundFilledAccent']),
  backgroundFilledAccentSecondary: (0, _euiThemeCommon.computed)(function (_ref25) {
    var _ref26 = (0, _slicedToArray2.default)(_ref25, 1),
      backgroundFilledAccent = _ref26[0];
    return backgroundFilledAccent;
  }, ['colors.backgroundFilledAccent']),
  backgroundFilledNeutral: (0, _euiThemeCommon.computed)(function (_ref27) {
    var _ref28 = (0, _slicedToArray2.default)(_ref27, 1),
      backgroundFilledNeutral = _ref28[0];
    return backgroundFilledNeutral;
  }, ['colors.backgroundFilledNeutral']),
  backgroundFilledSuccess: (0, _euiThemeCommon.computed)(function (_ref29) {
    var _ref30 = (0, _slicedToArray2.default)(_ref29, 1),
      backgroundFilledSuccess = _ref30[0];
    return backgroundFilledSuccess;
  }, ['colors.backgroundFilledSuccess']),
  backgroundFilledWarning: (0, _euiThemeCommon.computed)(function (_ref31) {
    var _ref32 = (0, _slicedToArray2.default)(_ref31, 1),
      backgroundFilledWarning = _ref32[0];
    return backgroundFilledWarning;
  }, ['colors.backgroundFilledWarning']),
  backgroundFilledRisk: (0, _euiThemeCommon.computed)(function (_ref33) {
    var _ref34 = (0, _slicedToArray2.default)(_ref33, 1),
      backgroundFilledRisk = _ref34[0];
    return backgroundFilledRisk;
  }, ['colors.backgroundFilledRisk']),
  backgroundFilledDanger: (0, _euiThemeCommon.computed)(function (_ref35) {
    var _ref36 = (0, _slicedToArray2.default)(_ref35, 1),
      backgroundFilledDanger = _ref36[0];
    return backgroundFilledDanger;
  }, ['colors.backgroundFilledDanger']),
  backgroundFilledText: (0, _euiThemeCommon.computed)(function (_ref37) {
    var _ref38 = (0, _slicedToArray2.default)(_ref37, 1),
      backgroundFilledText = _ref38[0];
    return backgroundFilledText;
  }, ['colors.backgroundFilledText']),
  backgroundFilledDisabled: (0, _euiThemeCommon.computed)(function (_ref39) {
    var _ref40 = (0, _slicedToArray2.default)(_ref39, 1),
      lightShade = _ref40[0];
    return (0, _manipulation.transparentize)(lightShade, 0.15);
  }, ['colors.lightShade']),
  backgroundEmptyPrimaryHover: (0, _euiThemeCommon.computed)(function (_ref41) {
    var _ref42 = (0, _slicedToArray2.default)(_ref41, 1),
      primary = _ref42[0];
    return (0, _manipulation.transparentize)(primary, 0.1);
  }, ['colors.primary']),
  backgroundEmptyAccentHover: (0, _euiThemeCommon.computed)(function (_ref43) {
    var _ref44 = (0, _slicedToArray2.default)(_ref43, 1),
      accent = _ref44[0];
    return (0, _manipulation.transparentize)(accent, 0.1);
  }, ['colors.accent']),
  backgroundEmptyAccentSecondaryHover: (0, _euiThemeCommon.computed)(function (_ref45) {
    var _ref46 = (0, _slicedToArray2.default)(_ref45, 1),
      success = _ref46[0];
    return (0, _manipulation.transparentize)(success, 0.1);
  }, ['colors.success']),
  backgroundEmptyNeutralHover: (0, _manipulation.transparentize)(_colors_severity.severityColors.neutral, 0.1),
  backgroundEmptySuccessHover: (0, _euiThemeCommon.computed)(function (_ref47) {
    var _ref48 = (0, _slicedToArray2.default)(_ref47, 1),
      success = _ref48[0];
    return (0, _manipulation.transparentize)(success, 0.1);
  }, ['colors.success']),
  backgroundEmptyWarningHover: (0, _euiThemeCommon.computed)(function (_ref49) {
    var _ref50 = (0, _slicedToArray2.default)(_ref49, 1),
      warning = _ref50[0];
    return (0, _manipulation.transparentize)(warning, 0.1);
  }, ['colors.warning']),
  backgroundEmptyRiskHover: (0, _manipulation.transparentize)(_colors_severity.severityColors.risk, 0.1),
  backgroundEmptyDangerHover: (0, _euiThemeCommon.computed)(function (_ref51) {
    var _ref52 = (0, _slicedToArray2.default)(_ref51, 1),
      danger = _ref52[0];
    return (0, _manipulation.transparentize)(danger, 0.1);
  }, ['colors.danger']),
  backgroundEmptyTextHover: (0, _euiThemeCommon.computed)(function (_ref53) {
    var _ref54 = (0, _slicedToArray2.default)(_ref53, 1),
      lightShade = _ref54[0];
    return (0, _manipulation.transparentize)(lightShade, 0.2);
  }, ['colors.lightShade']),
  textColorPrimary: (0, _euiThemeCommon.computed)(function (_ref55) {
    var _ref56 = (0, _slicedToArray2.default)(_ref55, 1),
      primaryText = _ref56[0];
    return primaryText;
  }, ['colors.primaryText']),
  textColorAccent: (0, _euiThemeCommon.computed)(function (_ref57) {
    var _ref58 = (0, _slicedToArray2.default)(_ref57, 1),
      accentText = _ref58[0];
    return accentText;
  }, ['colors.accentText']),
  textColorAccentSecondary: (0, _euiThemeCommon.computed)(function (_ref59) {
    var _ref60 = (0, _slicedToArray2.default)(_ref59, 1),
      successText = _ref60[0];
    return successText;
  }, ['colors.successText']),
  textColorNeutral: (0, _euiThemeCommon.computed)(function (_ref61) {
    var _ref62 = (0, _slicedToArray2.default)(_ref61, 1),
      textNeutral = _ref62[0];
    return textNeutral;
  }, ['colors.textNeutral']),
  textColorSuccess: (0, _euiThemeCommon.computed)(function (_ref63) {
    var _ref64 = (0, _slicedToArray2.default)(_ref63, 1),
      successText = _ref64[0];
    return successText;
  }, ['colors.successText']),
  textColorWarning: (0, _euiThemeCommon.computed)(function (_ref65) {
    var _ref66 = (0, _slicedToArray2.default)(_ref65, 1),
      warningText = _ref66[0];
    return warningText;
  }, ['colors.warningText']),
  textColorRisk: (0, _euiThemeCommon.computed)(function (_ref67) {
    var _ref68 = (0, _slicedToArray2.default)(_ref67, 1),
      textRisk = _ref68[0];
    return textRisk;
  }, ['colors.textRisk']),
  textColorDanger: (0, _euiThemeCommon.computed)(function (_ref69) {
    var _ref70 = (0, _slicedToArray2.default)(_ref69, 1),
      dangerText = _ref70[0];
    return dangerText;
  }, ['colors.dangerText']),
  textColorText: (0, _euiThemeCommon.computed)(function (_ref71) {
    var _ref72 = (0, _slicedToArray2.default)(_ref71, 1),
      text = _ref72[0];
    return text;
  }, ['colors.text']),
  textColorDisabled: (0, _euiThemeCommon.computed)(function (_ref73) {
    var _ref74 = (0, _slicedToArray2.default)(_ref73, 1),
      disabledText = _ref74[0];
    return disabledText;
  }, ['colors.disabledText']),
  textColorFilledPrimary: (0, _euiThemeCommon.computed)(function (_ref75) {
    var _ref76 = (0, _slicedToArray2.default)(_ref75, 3),
      primary = _ref76[0],
      ghost = _ref76[1],
      ink = _ref76[2];
    return isDark(primary) ? ghost : ink;
  }, ['colors.primary', 'colors.ghost', 'colors.ink']),
  textColorFilledAccent: (0, _euiThemeCommon.computed)(function (_ref77) {
    var _ref78 = (0, _slicedToArray2.default)(_ref77, 3),
      accent = _ref78[0],
      ghost = _ref78[1],
      ink = _ref78[2];
    return isDark(accent) ? ghost : ink;
  }, ['colors.accent', 'colors.ghost', 'colors.ink']),
  textColorFilledAccentSecondary: (0, _euiThemeCommon.computed)(function (_ref79) {
    var _ref80 = (0, _slicedToArray2.default)(_ref79, 3),
      success = _ref80[0],
      ghost = _ref80[1],
      ink = _ref80[2];
    var background = (0, _manipulation.tint)(success, 0.3);
    return isDark(background) ? ghost : ink;
  }, ['colors.success', 'colors.ghost', 'colors.ink']),
  textColorFilledNeutral: (0, _euiThemeCommon.computed)(function (_ref81) {
    var _ref82 = (0, _slicedToArray2.default)(_ref81, 2),
      ghost = _ref82[0],
      ink = _ref82[1];
    var background = (0, _manipulation.tint)(_colors_severity.severityColors.neutral, 0.3);
    return isDark(background) ? ghost : ink;
  }, ['colors.ghost', 'colors.ink']),
  textColorFilledSuccess: (0, _euiThemeCommon.computed)(function (_ref83) {
    var _ref84 = (0, _slicedToArray2.default)(_ref83, 3),
      success = _ref84[0],
      ghost = _ref84[1],
      ink = _ref84[2];
    var background = (0, _manipulation.tint)(success, 0.3);
    return isDark(background) ? ghost : ink;
  }, ['colors.success', 'colors.ghost', 'colors.ink']),
  textColorFilledWarning: (0, _euiThemeCommon.computed)(function (_ref85) {
    var _ref86 = (0, _slicedToArray2.default)(_ref85, 3),
      warning = _ref86[0],
      ghost = _ref86[1],
      ink = _ref86[2];
    return isDark(warning) ? ghost : ink;
  }, ['colors.warning', 'colors.ghost', 'colors.ink']),
  textColorFilledRisk: (0, _euiThemeCommon.computed)(function (_ref87) {
    var _ref88 = (0, _slicedToArray2.default)(_ref87, 2),
      ghost = _ref88[0],
      ink = _ref88[1];
    var background = (0, _manipulation.tint)(_colors_severity.severityColors.risk, 0.3);
    return isDark(background) ? ghost : ink;
  }, ['colors.ghost', 'colors.ink']),
  textColorFilledDanger: (0, _euiThemeCommon.computed)(function (_ref89) {
    var _ref90 = (0, _slicedToArray2.default)(_ref89, 3),
      danger = _ref90[0],
      ghost = _ref90[1],
      ink = _ref90[2];
    return isDark(danger) ? ghost : ink;
  }, ['colors.danger', 'colors.ghost', 'colors.ink']),
  textColorFilledText: (0, _euiThemeCommon.computed)(function (_ref91) {
    var _ref92 = (0, _slicedToArray2.default)(_ref91, 3),
      darkShade = _ref92[0],
      ghost = _ref92[1],
      ink = _ref92[2];
    return isDark(darkShade) ? ghost : ink;
  }, ['colors.darkShade', 'colors.ghost', 'colors.ink']),
  textColorFilledDisabled: (0, _euiThemeCommon.computed)(function (_ref93) {
    var _ref94 = (0, _slicedToArray2.default)(_ref93, 1),
      disabledText = _ref94[0];
    return disabledText;
  }, ['colors.disabledText'])
};
var _dark_buttons = _objectSpread(_objectSpread({}, _buttons), {}, {
  backgroundFilledDisabled: (0, _euiThemeCommon.computed)(function (_ref95) {
    var _ref96 = (0, _slicedToArray2.default)(_ref95, 1),
      lightShade = _ref96[0];
    return (0, _manipulation.transparentize)(lightShade, 0.15);
  }, ['colors.lightShade']),
  backgroundEmptyTextHover: (0, _euiThemeCommon.computed)(function (_ref97) {
    var _ref98 = (0, _slicedToArray2.default)(_ref97, 1),
      lightShade = _ref98[0];
    return (0, _manipulation.transparentize)(lightShade, 0.4);
  }, ['colors.lightShade']),
  textColorFilledAccent: (0, _euiThemeCommon.computed)(function (_ref99) {
    var _ref100 = (0, _slicedToArray2.default)(_ref99, 3),
      accent = _ref100[0],
      ghost = _ref100[1],
      ink = _ref100[2];
    return isDark(accent) ? ghost : ink;
  }, ['colors.accent', 'colors.ghost', 'colors.ink']),
  textColorFilledSuccess: (0, _euiThemeCommon.computed)(function (_ref101) {
    var _ref102 = (0, _slicedToArray2.default)(_ref101, 3),
      success = _ref102[0],
      ghost = _ref102[1],
      ink = _ref102[2];
    return isDark(success) ? ghost : ink;
  }, ['colors.success', 'colors.ghost', 'colors.ink']),
  textColorFilledText: (0, _euiThemeCommon.computed)(function (_ref103) {
    var _ref104 = (0, _slicedToArray2.default)(_ref103, 3),
      text = _ref104[0],
      ghost = _ref104[1],
      ink = _ref104[2];
    return isDark(text) ? ghost : ink;
  }, ['colors.text', 'colors.ghost', 'colors.ink'])
});
var buttons = exports.buttons = {
  LIGHT: _buttons,
  DARK: _dark_buttons
};