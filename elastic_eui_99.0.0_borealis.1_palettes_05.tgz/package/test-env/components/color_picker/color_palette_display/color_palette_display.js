"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.SIZES = exports.EuiColorPaletteDisplay = void 0;
var _extends2 = _interopRequireDefault(require("@babel/runtime/helpers/extends"));
var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime/helpers/objectWithoutProperties"));
var _react = _interopRequireDefault(require("react"));
var _propTypes = _interopRequireDefault(require("prop-types"));
var _classnames = _interopRequireDefault(require("classnames"));
var _services = require("../../../services");
var _color_palette_display_fixed = require("./color_palette_display_fixed");
var _color_palette_display_gradient = require("./color_palette_display_gradient");
var _color_palette_display = require("./color_palette_display.styles");
var _react2 = require("@emotion/react");
var _excluded = ["type", "palette", "className", "size"];
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
var SIZES = exports.SIZES = ['xs', 's', 'm'];
var EuiColorPaletteDisplay = exports.EuiColorPaletteDisplay = function EuiColorPaletteDisplay(_ref) {
  var _ref$type = _ref.type,
    type = _ref$type === void 0 ? 'fixed' : _ref$type,
    palette = _ref.palette,
    className = _ref.className,
    _ref$size = _ref.size,
    size = _ref$size === void 0 ? 's' : _ref$size,
    rest = (0, _objectWithoutProperties2.default)(_ref, _excluded);
  var classes = (0, _classnames.default)('euiColorPaletteDisplay', className);
  var styles = (0, _services.useEuiMemoizedStyles)(_color_palette_display.euiColorPaletteDisplayStyles);
  var cssStyles = [styles.euiColorPaletteDisplay, styles[size]];
  return (0, _react2.jsx)(_react.default.Fragment, null, type === 'fixed' ? (0, _react2.jsx)(_color_palette_display_fixed.EuiColorPaletteDisplayFixed, (0, _extends2.default)({
    css: cssStyles,
    className: classes,
    palette: palette
  }, rest)) : (0, _react2.jsx)(_color_palette_display_gradient.EuiColorPaletteDisplayGradient, (0, _extends2.default)({
    css: cssStyles,
    className: classes,
    palette: palette
  }, rest)));
};
EuiColorPaletteDisplay.propTypes = {
  /**
     * Height of the palette display
     */
  size: _propTypes.default.any,
  /**
     *   Specify the type of palette.
     *  `gradient`: each color fades into the next.
     */
  /**
     *  `fixed`: individual color blocks.
     */
  type: _propTypes.default.oneOfType([_propTypes.default.oneOf(["fixed"]), _propTypes.default.oneOf(["gradient"]).isRequired]),
  className: _propTypes.default.string,
  "aria-label": _propTypes.default.string,
  "data-test-subj": _propTypes.default.string,
  css: _propTypes.default.any,
  /**
     * Array of color `strings` or an array of #PaletteColorStop. The stops must be numbers in an ordered range.
     */
  /**
     * Array of color `strings` or an array of #PaletteColorStop. The stops must be numbers in an ordered range.
     */
  palette: _propTypes.default.oneOfType([_propTypes.default.arrayOf(_propTypes.default.string.isRequired).isRequired, _propTypes.default.arrayOf(_propTypes.default.any.isRequired).isRequired]).isRequired
};