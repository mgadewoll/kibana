"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
var _typeof = require("@babel/runtime/helpers/typeof");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.icon = void 0;
var _extends2 = _interopRequireDefault(require("@babel/runtime/helpers/extends"));
var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime/helpers/objectWithoutProperties"));
var React = _interopRequireWildcard(require("react"));
var _react2 = require("@emotion/react");
var _excluded = ["title", "titleId"];
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
// THIS IS A GENERATED FILE. DO NOT MODIFY MANUALLY. @see scripts/compile-icons.js
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != _typeof(e) && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
var EuiIconEditorChecklist = function EuiIconEditorChecklist(_ref) {
  var title = _ref.title,
    titleId = _ref.titleId,
    props = (0, _objectWithoutProperties2.default)(_ref, _excluded);
  return (0, _react2.jsx)("svg", (0, _extends2.default)({
    xmlns: "http://www.w3.org/2000/svg",
    width: 16,
    height: 16,
    fill: "none",
    viewBox: "0 0 16 16",
    "aria-labelledby": titleId
  }, props), title ? (0, _react2.jsx)("title", {
    id: titleId
  }, title) : null, (0, _react2.jsx)("path", {
    d: "M4.597 3a.411.411 0 0 0-.299.132l-1.85 1.993-.756-.7a.412.412 0 0 0-.28-.124.42.42 0 0 0-.292.098.333.333 0 0 0-.12.257.335.335 0 0 0 .127.254l1.064.982A.418.418 0 0 0 2.488 6a.411.411 0 0 0 .288-.126L4.904 3.58a.328.328 0 0 0 .095-.25.337.337 0 0 0-.126-.238A.421.421 0 0 0 4.597 3zm-.299 4.132A.411.411 0 0 1 4.597 7a.421.421 0 0 1 .276.093c.076.062.12.147.126.238a.328.328 0 0 1-.095.25L2.776 9.874a.411.411 0 0 1-.288.126.418.418 0 0 1-.297-.108L1.127 8.91A.335.335 0 0 1 1 8.656a.333.333 0 0 1 .12-.257.42.42 0 0 1 .292-.098c.108.005.21.05.28.123l.757.701 1.849-1.993zM4.597 11a.411.411 0 0 0-.299.132l-1.85 1.993-.756-.7a.412.412 0 0 0-.28-.124.421.421 0 0 0-.292.098.333.333 0 0 0-.12.257.335.335 0 0 0 .127.254l1.064.982a.418.418 0 0 0 .297.108.411.411 0 0 0 .288-.126l2.128-2.293a.328.328 0 0 0 .095-.25.337.337 0 0 0-.126-.238.421.421 0 0 0-.276-.093zM6.5 4a.5.5 0 0 0 0 1h7a.5.5 0 0 0 0-1h-7zM6 8.5a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7a.5.5 0 0 1-.5-.5zm.5 3.5a.5.5 0 0 0 0 1h7a.5.5 0 0 0 0-1h-7z"
  }));
};
var icon = exports.icon = EuiIconEditorChecklist;