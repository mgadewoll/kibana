"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "colorVis", {
  enumerable: true,
  get: function get() {
    return _colors_vis.colorVis;
  }
});
var _colors_vis = require("../../themes/amsterdam/global_styling/variables/_colors_vis");