export declare const forms: {
    maxWidth: string;
    LIGHT: {
        background: any;
        backgroundDisabled: any;
        backgroundReadOnly: any;
        backgroundFocused: any;
        backgroundAutofilled: any;
        prependBackground: any;
        border: any;
        borderDisabled: any;
        borderAutofilled: any;
        controlBorder: any;
        controlBorderSelected: any;
        controlBorderDisabled: any;
        controlBackgroundUnselected: string;
        controlBackgroundDisabled: any;
        colorHasPlaceholder: any;
        colorDisabled: any;
        iconDisabled: any;
    };
    DARK: {
        background: any;
        backgroundDisabled: any;
        backgroundReadOnly: any;
        backgroundFocused: any;
        backgroundAutofilled: any;
        prependBackground: any;
        border: any;
        borderDisabled: any;
        borderAutofilled: any;
        controlBorder: any;
        controlBorderSelected: any;
        controlBorderDisabled: any;
        controlBackgroundUnselected: string;
        controlBackgroundDisabled: any;
        colorHasPlaceholder: any;
        colorDisabled: any;
        iconDisabled: any;
    };
};
//# sourceMappingURL=_forms.d.ts.map