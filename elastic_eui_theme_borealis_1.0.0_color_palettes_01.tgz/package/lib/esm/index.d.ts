import { EuiThemeShape } from '@elastic/eui-theme-common';
export { colorVis } from './variables/colors/_colors_vis';
export declare const EUI_THEME_BOREALIS_KEY = "EUI_THEME_BOREALIS";
export declare const euiThemeBorealis: EuiThemeShape;
export declare const EuiThemeBorealis: {
    model: EuiThemeShape;
    root: EuiThemeShape;
    key: string;
};
