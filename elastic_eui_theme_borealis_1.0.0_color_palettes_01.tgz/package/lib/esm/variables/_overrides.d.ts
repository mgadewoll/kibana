import { _EuiThemeOverrides } from '@elastic/eui-theme-common';
export declare const overrides: _EuiThemeOverrides;
