export declare const severityColors: {
    unknown: string;
    neutral: string;
    success: string;
    warning: string;
    risk: string;
    danger: string;
};
