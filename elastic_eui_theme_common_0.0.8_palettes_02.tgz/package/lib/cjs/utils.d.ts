import { EuiThemeColorMode, EuiThemeColorModeStandard, EuiThemeSystem, EuiThemeShape, EuiThemeComputed } from './global_styling';
export declare const DEFAULT_COLOR_MODE: "LIGHT";
/**
 * Returns whether the provided color mode is `inverse`
 * @param {string} colorMode - `light`, `dark`, or `inverse`
 */
export declare const isInverseColorMode: (colorMode?: string | undefined) => colorMode is "INVERSE";
/**
 * Returns the color mode configured in the current EuiThemeProvider.
 * Returns the parent color mode if none is explicity set.
 * @param {string} colorMode - `light`, `dark`, or `inverse`
 * @param {string} parentColorMode - `LIGHT` or `DARK`; used as the fallback
 */
export declare const getColorMode: (colorMode?: EuiThemeColorMode | undefined, parentColorMode?: EuiThemeColorModeStandard | undefined) => EuiThemeColorModeStandard;
/**
 * Returns a value at a given path on an object.
 * If `colorMode` is provided, will scope the value to the appropriate color mode key (LIGHT\DARK)
 * @param {object} model - Object
 * @param {string} _path - Dot-notated string to a path on the object
 * @param {string} colorMode - `light` or `dark`
 */
export declare const getOn: (model: {
    [key: string]: any;
}, _path: string, colorMode?: EuiThemeColorModeStandard | undefined) => {
    [key: string]: any;
} | undefined;
/**
 * Sets a value at a given path on an object.
 * @param {object} model - Object
 * @param {string} _path - Dot-notated string to a path on the object
 * @param {any} string -  The value to set
 */
export declare const setOn: (model: {
    [key: string]: any;
}, _path: string, value: any) => boolean;
/**
 * Creates a class to store the `computer` method and its eventual parameters.
 * Allows for on-demand computation with up-to-date parameters via `getValue` method.
 * @constructor
 * @param {function} computer - Function to be computed
 * @param {string | array} dependencies - Dependencies passed to the `computer` as parameters
 */
export declare class Computed<T> {
    computer: (...values: any[]) => T;
    dependencies: string | string[];
    constructor(computer: (...values: any[]) => T, dependencies?: string | string[]);
    /**
     * Executes the `computer` method with the current state of the theme
     * by taking into account previously computed values and modifications.
     * @param {Proxy | object} base - Computed or uncomputed theme
     * @param {Proxy | object} modifications - Theme value overrides
     * @param {object} working - Partially computed theme
     * @param {string} colorMode - `light` or `dark`
     */
    getValue(base: EuiThemeSystem | EuiThemeShape | null, modifications: import("./types").RecursivePartial<EuiThemeShape> | undefined, working: Partial<EuiThemeComputed>, colorMode?: EuiThemeColorModeStandard): T;
}
/**
 * Returns a Class (`Computed`) that stores the arbitrary computer method
 * and references to its optional dependecies.
 * @param {function} computer - Arbitrary method to be called at compute time.
 * @param {string | array} dependencies - Values that will be provided to `computer` at compute time.
 */
export declare function computed<T>(computer: (value: EuiThemeComputed) => T): T;
export declare function computed<T>(computer: (value: any[]) => T, dependencies: string[]): T;
export declare function computed<T>(computer: (value: any) => T, dependencies: string): T;
/**
 * Takes an uncomputed theme, and computes and returns all values taking
 * into consideration value overrides and configured color mode.
 * Overrides take precedence, and only values in the current color mode
 * are computed and returned.
 * @param {Proxy} base - Object to transform into Proxy
 * @param {Proxy | object} over - Unique identifier or name
 * @param {string} colorMode - `light` or `dark`
 */
export declare const getComputed: <T = EuiThemeShape>(base: EuiThemeSystem<T>, over: Partial<EuiThemeSystem<T>>, colorMode: EuiThemeColorModeStandard) => EuiThemeComputed<T>;
/**
 * Builds a Proxy with a custom `handler` designed to self-reference values
 * and prevent arbitrary value overrides.
 * @param {object} model - Object to transform into Proxy
 * @param {string} key - Unique identifier or name
 */
export declare const buildTheme: <T extends {}>(model: T, key: string) => {
    model: T;
    root: T;
    key: string;
};
/**
 * Deeply merges two objects, using `source` values whenever possible.
 * @param {object} _target - Object with fallback values
 * @param {object} source - Object with desired values
 */
export declare const mergeDeep: (_target: {
    [key: string]: any;
}, source?: {
    [key: string]: any;
}) => {
    [key: string]: any;
};
/**
 * Returns token name string based on passed dynamic variants
 * and additional prefix/suffix
 */
export declare const getTokenName: (prefix: string, variant: string, suffix?: string | undefined) => string;
//# sourceMappingURL=utils.d.ts.map