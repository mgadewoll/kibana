import { EuiThemeColorModeStandard } from '../../services/theme/types';
export declare const getShadowColor: (color: string, opacity: number, colorMode: EuiThemeColorModeStandard) => string;
//# sourceMappingURL=shadows.d.ts.map