import { _EuiThemeBreakpoints } from './breakpoint';
export declare const breakpoint: _EuiThemeBreakpoints;
//# sourceMappingURL=_breakpoint.d.ts.map