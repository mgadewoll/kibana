import { RecursivePartial } from '../../types';
import { EUI_THEME_HIGH_CONTRAST_MODE_KEY, type EuiThemeShapeBase } from '../../services/theme/types';
/**
 * Theme specific conditional overrides, e.g. for high contrast mode
 */
export declare type _EuiThemeOverrides = {
    [EUI_THEME_HIGH_CONTRAST_MODE_KEY]: RecursivePartial<EuiThemeShapeBase>;
};
//# sourceMappingURL=overrides.d.ts.map