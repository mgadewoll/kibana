import type { CSSObject } from '@emotion/react';
import type { RecursivePartial, ValueOf } from '../../types';
import type { _EuiThemeAnimation } from '../../global_styling/variables/animations';
import type { _EuiThemeBreakpoints } from '../../global_styling/variables/breakpoint';
import type { _EuiThemeBorder } from '../../global_styling/variables/borders';
import type { _EuiThemeColors } from '../../global_styling/variables/colors';
import type { _EuiThemeBase, _EuiThemeSizes } from '../../global_styling/variables/size';
import type { _EuiThemeFont } from '../../global_styling/variables/typography';
import type { _EuiThemeFocus } from '../../global_styling/variables/states';
import type { _EuiThemeLevels } from '../../global_styling/variables/levels';
import type { _EuiThemeComponents } from '../../global_styling/variables/components';
import type { _EuiThemeFlags } from '../../global_styling/variables';
import type { _EuiThemeOverrides } from '../../global_styling/variables/overrides';
export declare const COLOR_MODES_STANDARD: {
    readonly light: "LIGHT";
    readonly dark: "DARK";
};
export declare const COLOR_MODES_INVERSE: "INVERSE";
export declare type EuiThemeColorModeInverse = typeof COLOR_MODES_INVERSE;
export declare type EuiThemeColorModeStandard = ValueOf<typeof COLOR_MODES_STANDARD>;
export declare type EuiThemeColorMode = 'light' | 'dark' | EuiThemeColorModeStandard | 'inverse' | EuiThemeColorModeInverse;
export declare type ColorModeSwitch<T = string> = {
    [key in EuiThemeColorModeStandard]: T;
} | T;
export declare type StrictColorModeSwitch<T = string> = {
    [key in EuiThemeColorModeStandard]: T;
};
export declare type EuiThemeHighContrastModeProp = boolean;
export declare type EuiThemeHighContrastMode = 'forced' | 'preferred' | false;
export declare const EUI_THEME_HIGH_CONTRAST_MODE_KEY: "HCM";
export declare const EUI_THEME_OVERRIDES_KEY: "overrides";
export declare type EuiThemeShapeBase = {
    colors: _EuiThemeColors;
    /** - Default value: 16 */
    base: _EuiThemeBase;
    /**
     * See {@link https://eui.elastic.co/#/theming/sizing | Reference} for more information
     */
    size: _EuiThemeSizes;
    font: _EuiThemeFont;
    border: _EuiThemeBorder;
    focus: _EuiThemeFocus;
    animation: _EuiThemeAnimation;
    breakpoint: _EuiThemeBreakpoints;
    levels: _EuiThemeLevels;
    components: _EuiThemeComponents;
    flags: _EuiThemeFlags;
};
export declare type EuiThemeShape = EuiThemeShapeBase & {
    overrides?: _EuiThemeOverrides;
};
export declare type EuiThemeSystem<T = {}> = {
    root: EuiThemeShape & T;
    model: EuiThemeShape & T;
    key: string;
};
export declare type EuiThemeModifications<T = {}> = RecursivePartial<EuiThemeShape & T>;
export declare type ComputedThemeShape<T, P = string | number | bigint | boolean | null | undefined> = T extends P | ColorModeSwitch<infer X> ? T extends ColorModeSwitch<X> ? X extends P ? X : {
    [K in keyof (X & Exclude<T, keyof X | keyof StrictColorModeSwitch>)]: ComputedThemeShape<(X & Exclude<T, keyof X | keyof StrictColorModeSwitch>)[K], P>;
} : T : {
    [K in keyof T]: ComputedThemeShape<T[K], P>;
};
export declare type EuiThemeComputed<T = {}> = ComputedThemeShape<EuiThemeShape & T> & {
    themeName: string;
};
export declare type EuiThemeNested = {
    isGlobalTheme: boolean;
    hasDifferentColorFromGlobalTheme: boolean;
    bodyColor: string;
    colorClassName: string;
    setGlobalCSSVariables: Function;
    globalCSSVariables?: CSSObject;
    setNearestThemeCSSVariables: Function;
    themeCSSVariables?: CSSObject;
};
export interface UseEuiTheme<T extends {} = {}> {
    euiTheme: EuiThemeComputed<T>;
    colorMode: EuiThemeColorModeStandard;
    highContrastMode: EuiThemeHighContrastMode;
    modifications: EuiThemeModifications<T>;
}
